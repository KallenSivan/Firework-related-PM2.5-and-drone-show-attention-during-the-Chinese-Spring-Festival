from pathlib import Path
import io
import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.patches import Patch
from PIL import Image, ImageDraw, ImageFont
from libpysal.weights import Queen

ROOT = Path(__file__).resolve().parent.parent
HERE = ROOT / 'results/figures'
HERE.mkdir(parents=True, exist_ok=True)
OUT = HERE / 'panels'
OUT.mkdir(exist_ok=True)
# Visual configuration and rendering block preserved from submitted 02_lisa_updated_B.py.
# Only island drawing and legend exclusion are added; no statistical rerun occurs here.
config = 'LCC = "+proj=lcc +lat_1=25 +lat_2=47 +lon_0=104 +datum=WGS84 +units=m +no_defs"\nEDGE_COLOR, NO_DATA_COLOR = "#444444", "#F4F4F4"\n\n# 布局参数 - 参考你的画图代码\nFIG_W, FIG_H, DPI = 16, 10, 100\nML, MB, MW, MH = 0.05, 0.08, 0.82, 0.85 \nIN_W, IN_H = 0.11, 0.22                  \nIN_X, IN_Y = (ML + MW) - IN_W, MB        \nLINEWIDTH = 1.2\nX_LIMIT_RIGHT_OFFSET = 55000\n\n# LISA聚类颜色 - 使用英文标签\n\nLISA_COLORS = {\n    \'High-High\': \'#FF0000\',     # 红色\n    \'Low-Low\': \'#0000FF\',       # 蓝色\n    \'High-Low\': \'#FFC0CB\',      # 粉色\n    \'Low-High\': \'#87CEEB\',      # 浅蓝色\n    \'Not Significant\': \'#E0E0E0\'  # 浅灰色（比白色深一些）\n}\n\n'
block = 'def render_inset_image(gdf_data, cluster_colors_dict):\n    """绘制南海诸岛插图"""\n    px_w, px_h = int(IN_W*FIG_W*DPI), int(IN_H*FIG_H*DPI)\n    fig_in = plt.figure(figsize=(px_w/DPI, px_h/DPI), dpi=DPI)\n    ax_in = fig_in.add_axes([0, 0, 1, 1])\n    ax_in.set_axis_off()\n    \n    # 绘制所有城市（灰色背景）\n    gdf_proj.plot(ax=ax_in, color=NO_DATA_COLOR, edgecolor=EDGE_COLOR, linewidth=0.1)\n    \n    # 绘制聚类\n    for cluster_type, color in cluster_colors_dict.items():\n        subset = gdf_data[gdf_data[\'cluster_type\'] == cluster_type]\n        if not subset.empty:\n            subset.plot(ax=ax_in, color=color, edgecolor=EDGE_COLOR, linewidth=0.1)\n    \n    # 添加南海诸岛\n    if nine_line is not None:\n        nine_line.plot(ax=ax_in, color="black", linewidth=0.6)\n    \n    # 设置南海诸岛范围\n    ax_in.set_xlim(550000, 2050000)\n    ax_in.set_ylim(-200000, 2750000)\n    \n    # 保存为图像\n    import io\n    buf = io.BytesIO()\n    fig_in.savefig(buf, format="png", dpi=DPI, bbox_inches="tight", pad_inches=0)\n    buf.seek(0)\n    img = plt.imread(buf)\n    plt.close(fig_in)\n    return img\n\n# 绘制主图\nfig = plt.figure(figsize=(FIG_W, FIG_H), dpi=DPI)\nax = fig.add_axes([ML, MB, MW, MH])\n\n# 绘制所有城市（灰色背景）\ngdf_proj.plot(ax=ax, color=NO_DATA_COLOR, edgecolor=EDGE_COLOR, linewidth=0.2)\n\n# 绘制聚类（按顺序：先不显著，再其他）\n# 先绘制不显著区域\nsubset = analysis_gdf[analysis_gdf[\'cluster_type\'] == \'Not Significant\']\nif not subset.empty:\n    subset.plot(ax=ax, color=LISA_COLORS[\'Not Significant\'], edgecolor=EDGE_COLOR, linewidth=0.25)\n\n# 再绘制其他类型\nfor cluster_type in [\'High-High\', \'Low-Low\', \'High-Low\', \'Low-High\', \'Not tested (island)\']:\n    subset = analysis_gdf[analysis_gdf[\'cluster_type\'] == cluster_type]\n    if not subset.empty:\n        subset.plot(ax=ax, color=LISA_COLORS[cluster_type], edgecolor=EDGE_COLOR, linewidth=0.25)\n\n# 添加南海诸岛\nif nine_line is not None:\n    nine_line.plot(ax=ax, color=EDGE_COLOR, linewidth=0.6)\n\n# 设置视野范围\nb = gdf_proj.total_bounds\nax.set_xlim(b[0]-300000, b[2] + X_LIMIT_RIGHT_OFFSET) \nax.set_ylim(2000000, b[3]+100000)\nax.set_xticks([])\nax.set_yticks([])\nfor s in ax.spines.values():\n    s.set_visible(False)\n\n# 添加南海诸岛插图\ninset_img = render_inset_image(analysis_gdf, LISA_COLORS)\nax_in = fig.add_axes([IN_X, IN_Y, IN_W, IN_H])\nax_in.imshow(inset_img, origin=\'upper\')\nax_in.set_axis_off()\n\n# 添加边框\nmain_rect = mpl.patches.Rectangle((ML, MB), MW, MH, transform=fig.transFigure, \n                                  facecolor="none", edgecolor="black", linewidth=LINEWIDTH, zorder=5)\nfig.patches.append(main_rect)\ntop_l = mpl.lines.Line2D([IN_X, IN_X+IN_W], [IN_Y+IN_H, IN_Y+IN_H], \n                         transform=fig.transFigure, color="black", linewidth=LINEWIDTH, zorder=10)\nleft_l = mpl.lines.Line2D([IN_X, IN_X], [IN_Y, IN_Y+IN_H], \n                          transform=fig.transFigure, color="black", linewidth=LINEWIDTH, zorder=10)\nfig.lines.extend([top_l, left_l])\n\n# 添加图例 - 放在左下方内部\nfrom matplotlib.patches import Patch\nlegend_elements = []\nfor cluster_type, color in LISA_COLORS.items():\n    if cluster_type not in [\'Not Significant\', \'Not tested (island)\'] and not analysis_gdf[analysis_gdf[\'cluster_type\'] == cluster_type].empty:\n        legend_elements.append(Patch(facecolor=color, edgecolor=EDGE_COLOR, label=cluster_type))\n\n# 图例放在左下方内部\nax.legend(handles=legend_elements, loc=\'lower left\', fontsize=10, \n          frameon=True, fancybox=True, framealpha=0.9)\n\n# 标题只保留年份\nax.set_title(f\'{year}\', fontsize=14, pad=20)\n\n# 保存图片\nplt.savefig(os.path.join(output_dir, f"lisa_cluster_map_{year}.png"), dpi=DPI, bbox_inches=\'tight\')\nplt.close()\n'
env = dict(np=np, pd=pd, plt=plt, mpl=mpl, Patch=Patch, os=__import__('os'))
exec(config, env)
env['LISA_COLORS']['Not tested (island)'] = '#909090'
gdf = gpd.read_file(ROOT / 'shapefiles/中国_市.shp')
weights = Queen.from_dataframe(gdf, use_index=False)
island_names = set(gdf.iloc[weights.islands]['name'])
assert island_names == {'舟山市', '台湾省', '三沙市'}, island_names
print('Verified Queen islands:', len(island_names))
env.update(gdf_proj=gdf.to_crs(env['LCC']), nine_line=gpd.read_file(ROOT / 'shapefiles/中国_市line.shp').to_crs(env['LCC']), output_dir=str(OUT))
for year in range(2020, 2026):
    data = pd.read_csv(ROOT / f'results/moran_analysis_updated_B/local_moran/local_moran_{year}.csv')
    assert set(data.loc[data.is_island, 'name']) == island_names
    env.update(year=year, analysis_gdf=env['gdf_proj'].merge(data, on='name', validate='one_to_one'))
    exec(block, env)

# Retain the published six-panel canvas and panel placement.
canvas = Image.new('RGB', (4036, 1964), 'white')
from matplotlib import font_manager
font = ImageFont.truetype(font_manager.findfont('Arial', fallback_to_default=True), 40)
for i, year in enumerate(range(2020, 2026)):
    panel = Image.open(OUT / f'lisa_cluster_map_{year}.png').convert('RGB')
    assert panel.width == 1332 and panel.height in (911, 912), panel.size
    panel = panel.crop((0, 0, 1332, 911))
    x, y = (i % 3) * 1352, (i // 3) * 932
    canvas.paste(panel, (x, y))
    ImageDraw.Draw(canvas).text((x + 54, y + 55), f'({chr(97+i)})', fill='black', font=font)
fig = plt.figure(figsize=(40.36, 1), dpi=100)
fig.legend([Patch(facecolor=c, edgecolor='.4') for c in env['LISA_COLORS'].values()],
           list(env['LISA_COLORS']), loc='center', ncol=6, frameon=False, fontsize=22,
           handlelength=1.2, columnspacing=1.2)
buf = io.BytesIO()
fig.savefig(buf, format='png', dpi=100)
plt.close(fig)
buf.seek(0)
canvas.paste(Image.open(buf).convert('RGB'), (0, 1864))
canvas.save(HERE / 'FIGURE2_Queen.png', dpi=(300, 300))
canvas.thumbnail((1800, 1000))
canvas.save(HERE / 'FIGURE2_Queen_preview.png')
print(HERE / 'FIGURE2_Queen.png')
