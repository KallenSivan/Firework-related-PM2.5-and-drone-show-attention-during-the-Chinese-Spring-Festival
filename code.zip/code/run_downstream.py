from pathlib import Path
import os, subprocess, sys
ROOT = Path(__file__).resolve().parent.parent
tasks = [('01_moran_updated_B.py', 'moran_analysis_updated_B'), ('02_lisa_updated_B.py', 'moran_analysis_updated_B'), ('03_gwr_annual_firework.py', 'gwr'), ('04_gwr_diagnostics.py', 'gwr/diagnostics_rerun'), ('05_ols_pooled_2023_2024.py', 'ols_pooled'), ('06_ols_window_split.py', 'ols_window_split'), ('07_figure2_queen.py', 'figures')]
env = dict(os.environ, PYTHONIOENCODING='utf-8', MPLBACKEND='Agg', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
for script, folder in tasks:
    out = ROOT / 'results' / folder; out.mkdir(parents=True, exist_ok=True)
    print('RUN', script, flush=True)
    with (out / (script[:-3] + '.log')).open('w', encoding='utf-8') as log:
        subprocess.run([sys.executable, str(ROOT / 'code' / script)], cwd=out, env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
    print('DONE', script, flush=True)
